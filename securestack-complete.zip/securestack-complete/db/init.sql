CREATE TABLE IF NOT EXISTS project_status (
    id SERIAL PRIMARY KEY,
    message TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO project_status (message)
VALUES ('SecureStack database is ready!');
