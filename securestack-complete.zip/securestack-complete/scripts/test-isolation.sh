#!/usr/bin/env bash
set -u
cd "$(dirname "$0")/.."

printf '\n[1/3] Frontend/API -> Backend -> Database\n'
if command -v curl >/dev/null 2>&1; then
  curl --fail --silent --show-error http://localhost:8080/api || { echo 'FAIL: API/database test failed'; exit 1; }
  echo
else
  echo 'curl is required on the host to test the API.'
  exit 1
fi

printf '\n[2/3] Database is not published to the host\n'
if sudo docker compose ps database --format json | grep -q '0.0.0.0:5432'; then
  echo 'FAIL: database port appears published on host.'
  exit 1
else
  echo 'PASS: Compose does not publish database port 5432.'
fi

printf '\n[3/3] Direct frontend-network DNS access to database\n'
NETWORK="$(sudo docker network ls --format '{{.Name}}' | grep '_frontend_net$' | head -n 1 || true)"
if [ -z "$NETWORK" ]; then
  echo 'Could not find the Compose frontend network. Run this script from the project directory after docker compose up -d.'
  exit 1
fi
if sudo docker run --rm --network "$NETWORK" busybox:1.36 sh -c 'nslookup database >/dev/null 2>&1'; then
  echo 'FAIL: database hostname resolved on frontend network; inspect network attachments.'
  exit 1
else
  echo 'PASS: database service name is not resolvable from the frontend-only network.'
fi

echo '\nIsolation checks completed. Note: DNS isolation is one test; the database must remain attached only to backend_net.'
