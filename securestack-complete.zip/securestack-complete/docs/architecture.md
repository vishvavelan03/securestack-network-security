# SecureStack network architecture

```mermaid
flowchart LR
    Browser((Browser)) -->|HTTP :8080| FE[Frontend: Nginx]
    subgraph frontend_net[Docker network: frontend_net]
      FE -->|HTTP /api| BE[Backend: Flask :5000]
    end
    subgraph backend_net[Docker network: backend_net - internal]
      BE -->|PostgreSQL :5432| DB[(Database: PostgreSQL)]
    end
    FE -. direct database access is not allowed .-> DB
```

- `frontend` is attached only to `frontend_net` and publishes host port `8080`.
- `backend` is attached to both `frontend_net` and `backend_net` so it can receive frontend requests and reach the database.
- `database` is attached only to `backend_net`; its port is not published on the host.
- `backend_net` is declared `internal: true` to isolate that network from external connectivity.
