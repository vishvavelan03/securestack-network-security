# SecureStack — Multi-Container Network Isolation

SecureStack is a demonstration of least-privilege communication between a frontend, backend API, and database using Docker Compose networks.

## Problem statement

In a multi-container application, placing all services on one shared network can allow components to reach services they do not need. SecureStack separates network access so that the frontend can call the backend, the backend can query PostgreSQL, and the frontend has no direct network path to the database.

## Architecture

- **Frontend:** Nginx static dashboard, published on host port `8080`.
- **Backend:** Flask API, container port `5000`, not published on the host.
- **Database:** PostgreSQL 16, container port `5432`, not published on the host.
- **`frontend_net`:** frontend + backend.
- **`backend_net`:** backend + database; marked `internal: true`.

See [`docs/architecture.md`](docs/architecture.md) for the diagram.

## Requirements

- Docker Engine
- Docker Compose v2 (`docker compose`)
- Ports `8080` available on the host

## Run locally or on EC2

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
cd securestack
cp .env.example .env
nano .env   # Set a strong demo password; keep .env private
sudo docker compose up -d --build
sudo docker compose ps
curl http://localhost:8080/api
```

Open `http://YOUR_SERVER_PUBLIC_IP:8080` in a browser. On AWS, add an inbound TCP `8080` security-group rule scoped to your evaluator's IP where possible. Keep SSH restricted to a trusted IP. Do not add inbound rules for ports `5000` or `5432`.

If you have an existing database volume from an earlier version, `db/init.sql` runs automatically only when PostgreSQL initializes a new data directory. The API expects the `project_status` table to exist; if the database was initialized earlier without that table, apply the SQL in `db/init.sql` using `psql` rather than deleting the database volume.

## Connectivity and isolation tests

```bash
# Frontend -> backend -> database API test
curl --fail http://localhost:8080/api

# Backend health through the frontend proxy
curl --fail http://localhost:8080/health

# Network isolation checks (requires sudo Docker access and internet to pull busybox if absent)
./scripts/test-isolation.sh
```

Expected API JSON includes `"backend": "Connected"` and `"database": "Connected"`. The isolation script verifies that port 5432 is not published and that the `database` service name cannot be resolved from a temporary container attached only to the frontend network. For the demonstration, also show in `docker network inspect` that frontend is attached only to `frontend_net`, database only to `backend_net`, and backend to both.

## Useful commands

```bash
sudo docker compose logs --tail=100 frontend backend database
sudo docker compose restart frontend
sudo docker compose config
sudo docker network inspect securestack_frontend_net
sudo docker network inspect securestack_backend_net
```

## Security notes

- `.env` is ignored by Git; never commit passwords, SSH private keys, or cloud credentials.
- The password in `.env.example` is a placeholder. Set a strong unique password before deployment.
- Database and backend ports are not host-published.
- This is an educational demo, not a production-hardened service; use TLS, managed secrets, logging, and tighter cloud ingress controls for production.

## GitHub publishing

Create an empty GitHub repository named `securestack` (do not initialize it with a README), then run inside this folder:

```bash
git init
git add .
git commit -m "Build SecureStack network isolation demo"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/securestack.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username. The public repository URL will be `https://github.com/YOUR_USERNAME/securestack`.
