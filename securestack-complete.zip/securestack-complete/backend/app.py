import os
import socket
from flask import Flask, jsonify
import psycopg2

app = Flask(__name__)


def db_connection():
    return psycopg2.connect(
        host=os.getenv("DB_HOST", "database"),
        port=int(os.getenv("DB_PORT", "5432")),
        dbname=os.getenv("POSTGRES_DB", "securedb"),
        user=os.getenv("POSTGRES_USER", "secureuser"),
        password=os.getenv("POSTGRES_PASSWORD", "SecureStackDemo_2026"),
        connect_timeout=3,
    )


@app.get("/health")
def health():
    return jsonify({"status": "healthy", "service": "backend"}), 200


@app.get("/api")
def api_status():
    try:
        with db_connection() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT version()")
                version = cur.fetchone()[0]
                cur.execute("SELECT message FROM project_status ORDER BY id DESC LIMIT 1")
                row = cur.fetchone()
        return jsonify({
            "project": "SecureStack",
            "backend": "Connected",
            "container": socket.gethostname(),
            "database": "Connected",
            "database_version": version,
            "database_message": row[0] if row else "Database is ready",
        }), 200
    except Exception as exc:
        app.logger.exception("Database connectivity test failed")
        return jsonify({"project": "SecureStack", "backend": "Running", "database": "Disconnected", "error": str(exc)}), 503


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
